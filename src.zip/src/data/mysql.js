const mysql = {
    products : [
        {
            text: 'Restaurante Raudales'
        }
    ]
}

export default mysql;