export const menuData = [
    { image: "img.raudales.jpg", name: "Mojarra Frita" },
    { image: "camaron.jpg", name: "Camarones al ajo" },
    { image: "caldogallina.jpg", name: "Caldo Gallina" },
    { image: "camaronempanizado.jpg", name: "Camarones Empanizados" },
    { image: "consomecamarones.jpg", name: "Consome Camarones" },
    { image: "coctel.jpg", name: "Coctel de Camarones" },
    { image: "cochito.jpg", name: "Cochito Horneado" },
    { image: "Lomorelleno.jpg", name: "Lomo Relleno" },
    { image: "birria.jpg", name: "Birria Borrego" },
    { image: "charolacamarones.jpg", name: "Charola de Camarones" },
    { image: "chamorro.jpg", name: "Chamorro al Vapor" },
    { image: "chile.jpg", name: "Chile Relleno" },
];

  