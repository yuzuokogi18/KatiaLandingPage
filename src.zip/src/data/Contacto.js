export const contactoData = {
    title: "Contacto:",
    address: "Nos encontramos en:\n\nCarretera a Benito Juárez, Colonia Independencia s/n, 30360 Chis.",
    phone: "Teléfono: 992-115-95-96",
    email: "Correo electrónico: restauranteraudales@gmail.com",
    note: "\"Facturamos\""
  };
  