import Fondo from "../molecules/Fondo";
import image from '../../../public/vite.svg'





function Section2() {
    return (
    <>
        <Fondo></Fondo>  
    </>)
}

export default Section2;