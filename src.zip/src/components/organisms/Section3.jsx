import Menu from "../molecules/Menu";
import image from '../../../public/vite.svg'





function Section2() {
    return (
    <>
        <Menu></Menu>  
    </>)
}

export default Section2;