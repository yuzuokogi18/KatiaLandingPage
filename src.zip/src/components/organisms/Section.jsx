import Grid from "../molecules/Grid";
import image from '../../../public/vite.svg'





function Section() {
    return (
    <>
        <Grid></Grid>  
    </>)
}

export default Section;