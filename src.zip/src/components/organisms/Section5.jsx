import Contacto from "../molecules/Contacto";







function Section5() {
    return (
    <>
        <Contacto></Contacto>  
    </>)
}

export default Section5;